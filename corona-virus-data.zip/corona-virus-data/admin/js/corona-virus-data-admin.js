(function( $ ) {
	'use strict';

})( jQuery );
